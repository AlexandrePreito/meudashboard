'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Eye, EyeOff, UserPlus } from 'lucide-react';
import LoadingSpinner from '@/components/ui/LoadingSpinner';

// Componente de barras animadas
function AnimatedBars() {
  return (
    <div className="flex items-end justify-between h-32 w-full">
      {[40, 65, 45, 80, 55, 70, 50].map((height, i) => (
        <div
          key={i}
          className="flex-1 bg-gradient-to-t from-cyan-500/40 to-cyan-400/20 rounded-t mx-1"
          style={{
            height: `${height}%`,
            animation: `barPulse 2s ease-in-out ${i * 0.2}s infinite`
          }}
        />
      ))}
    </div>
  );
}

// Componente de número animado
function AnimatedNumber({ value, label, delay }: { value: string; label: string; delay: number }) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShow(true), delay);
    return () => clearTimeout(timer);
  }, [delay]);

  return (
    <div
      className={`bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 transition-all duration-700 ${
        show ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
      }`}
    >
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="text-xs text-slate-400">{label}</p>
    </div>
  );
}

// Componente de linha de gráfico animada
function AnimatedLineChart() {
  return (
    <svg viewBox="0 0 200 60" className="w-full h-20" preserveAspectRatio="none">
      <defs>
        <linearGradient id="lineGradientCadastro" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.8" />
        </linearGradient>
      </defs>
      <path
        d="M0,45 Q30,40 60,30 T120,20 T160,25 T200,10"
        fill="none"
        stroke="url(#lineGradientCadastro)"
        strokeWidth="2"
        className="animate-dash"
        style={{
          strokeDasharray: 300,
          strokeDashoffset: 300,
          animation: 'dashDraw 3s ease-out forwards'
        }}
      />
      <path
        d="M0,45 Q30,40 60,30 T120,20 T160,25 T200,10 L200,60 L0,60 Z"
        fill="url(#lineGradientCadastro)"
        opacity="0.1"
      />
    </svg>
  );
}

// Nome da marca (estilo igual ao login/landing)
function BrandName({ size = 'text-xl' }: { size?: string }) {
  return (
    <span className={`font-bold text-slate-900 ${size}`}>
      <span className="text-[1.2em]">M</span>eu<span className="text-[1.2em]">D</span>ashboard
    </span>
  );
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function CadastroPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [transitioning, setTransitioning] = useState(false);

  const validate = () => {
    if (!fullName.trim()) {
      setError('Nome completo é obrigatório');
      return false;
    }
    if (!email.trim()) {
      setError('Email é obrigatório');
      return false;
    }
    if (!EMAIL_REGEX.test(email.trim())) {
      setError('Formato de email inválido');
      return false;
    }
    if (!companyName.trim()) {
      setError('Nome da empresa é obrigatório');
      return false;
    }
    if (companyName.trim().length < 2) {
      setError('Nome da empresa deve ter pelo menos 2 caracteres');
      return false;
    }
    if (password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    if (!validate()) return;

    setLoading(true);
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          full_name: fullName.trim(),
          email: email.trim().toLowerCase(),
          company_name: companyName.trim(),
          password,
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setTransitioning(true);
        setTimeout(() => router.push('/dev'), 800);
      } else {
        setError(data.error || 'Erro ao criar conta. Tente novamente.');
      }
    } catch (err) {
      setError('Erro ao conectar com o servidor');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className={`min-h-screen flex ${transitioning ? 'page-transition' : ''}`} suppressHydrationWarning>
        {/* Lado esquerdo - Dashboard Animado */}
        <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" />
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-[100px] animate-pulse" style={{ animationDuration: '4s' }} />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-[100px] animate-pulse" style={{ animationDuration: '5s', animationDelay: '1s' }} />
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: '50px 50px'
            }}
          />

          <div className="relative z-10 flex flex-col justify-center p-12 w-full">
            <div className="grid grid-cols-2 gap-4 mb-8">
              <AnimatedNumber value="R$ 284k" label="Faturamento" delay={200} />
              <AnimatedNumber value="+18.5%" label="Crescimento" delay={400} />
              <AnimatedNumber value="1.247" label="Clientes" delay={600} />
              <AnimatedNumber value="94.2%" label="Satisfação" delay={800} />
            </div>

            <div
              className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 mb-8"
              style={{ animation: 'float 6s ease-in-out infinite' }}
            >
              <p className="text-xs text-slate-400 mb-3">Evolução Mensal</p>
              <AnimatedLineChart />
            </div>

            <div
              className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10"
              style={{ animation: 'float 6s ease-in-out 0.5s infinite' }}
            >
              <p className="text-xs text-slate-400 mb-3">Vendas por Período</p>
              <AnimatedBars />
            </div>

            <div className="mt-8">
              <p className="text-lg text-slate-400">Seus dados, suas decisões</p>
              <div className="flex flex-wrap gap-2 mt-3">
                <span className="px-2.5 py-1 bg-white/10 rounded-lg text-xs text-slate-300">📊 Power BI</span>
                <span className="px-2.5 py-1 bg-white/10 rounded-lg text-xs text-slate-300">🧠 IA</span>
                <span className="px-2.5 py-1 bg-white/10 rounded-lg text-xs text-slate-300">🔔 Alertas</span>
              </div>
            </div>
          </div>

          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-cyan-400/30 rounded-full"
              style={{
                top: `${20 + i * 15}%`,
                left: `${10 + i * 12}%`,
                animation: `float ${3 + i * 0.5}s ease-in-out ${i * 0.3}s infinite`
              }}
            />
          ))}
        </div>

        {/* Lado direito - Formulário */}
        <div className={`w-full lg:w-1/2 flex items-center justify-center p-8 bg-white ${transitioning ? 'form-transition' : ''}`}>
          <div className="w-full max-w-md">
            <div className="mb-8">
              <BrandName size="text-lg" />
              <h1 className="text-2xl font-semibold text-gray-900 mt-4">Crie sua conta grátis</h1>
              <p className="text-gray-500 mt-2">Comece a monitorar seus dashboards em minutos</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label htmlFor="full_name" className="block text-sm font-medium text-gray-700 mb-1.5">
                  Nome completo
                </label>
                <input
                  type="text"
                  id="full_name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  disabled={loading}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed transition-all"
                  placeholder="João Silva"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1.5">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  disabled={loading}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed transition-all"
                  placeholder="seu@email.com"
                />
              </div>

              <div>
                <label htmlFor="company_name" className="block text-sm font-medium text-gray-700 mb-1.5">
                  Nome da empresa
                </label>
                <input
                  type="text"
                  id="company_name"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  required
                  disabled={loading}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed transition-all"
                  placeholder="Minha Empresa Ltda"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1.5">
                  Senha
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    disabled={loading}
                    minLength={6}
                    className="w-full px-4 py-3 pr-12 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed transition-all"
                    placeholder="Mínimo 6 caracteres"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="p-4 bg-red-50 border border-red-100 rounded-xl">
                  <p className="text-sm text-red-600">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-slate-900 text-white py-3.5 px-4 rounded-xl font-medium hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:ring-offset-2 disabled:bg-slate-400 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <LoadingSpinner size={20} />
                    Criando conta...
                  </>
                ) : (
                  <>
                    <UserPlus size={20} />
                    Criar conta grátis
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <span className="inline-flex items-center gap-1 text-xs text-gray-500">✓ 5 grupos grátis</span>
              <span className="inline-flex items-center gap-1 text-xs text-gray-500">✓ 15 usuários</span>
              <span className="inline-flex items-center gap-1 text-xs text-gray-500">✓ 15 dashboards</span>
            </div>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-500">
                Já tem conta?{' '}
                <Link href="/login" className="text-blue-600 hover:text-blue-700 font-medium">
                  Fazer login
                </Link>
              </p>
            </div>

            <div className="mt-6 pt-6 border-t border-gray-100">
              <p className="text-center text-xs text-gray-400">Ambiente seguro com criptografia de dados</p>
            </div>
          </div>
        </div>
      </div>

      {transitioning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-white transition-overlay">
          <div className="flex flex-col items-center gap-4 transition-spinner">
            <svg viewBox="0 0 100 100" width={48} height={48} className="animate-spin" style={{ animationDuration: '1.5s' }}>
              <defs>
                <linearGradient id="transitionGradCadastro" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#06b6d4" />
                  <stop offset="50%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#8b5cf6" />
                </linearGradient>
              </defs>
              <g fill="url(#transitionGradCadastro)">
                <rect x="45" y="10" width="10" height="80" rx="5" />
                <rect x="45" y="10" width="10" height="80" rx="5" transform="rotate(60 50 50)" />
                <rect x="45" y="10" width="10" height="80" rx="5" transform="rotate(120 50 50)" />
              </g>
            </svg>
            <p className="text-slate-600 text-sm font-medium">Configurando seu ambiente...</p>
          </div>
        </div>
      )}
    </>
  );
}
