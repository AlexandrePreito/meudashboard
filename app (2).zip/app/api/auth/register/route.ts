import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const jwtSecret = process.env.JWT_SECRET || 'your-secret-key';

function getSupabase() {
  return createClient(supabaseUrl, supabaseKey);
}

export async function POST(request: NextRequest) {
  try {
    const { full_name, email, password, company_name } = await request.json();

    // ========== VALIDAÇÕES ==========
    if (!full_name || !email || !password || !company_name) {
      return NextResponse.json(
        { error: 'Todos os campos são obrigatórios' },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'A senha deve ter pelo menos 6 caracteres' },
        { status: 400 }
      );
    }

    if (company_name.trim().length < 2) {
      return NextResponse.json(
        { error: 'Nome da empresa deve ter pelo menos 2 caracteres' },
        { status: 400 }
      );
    }

    const emailNormalized = email.toLowerCase().trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailNormalized)) {
      return NextResponse.json(
        { error: 'Formato de email inválido' },
        { status: 400 }
      );
    }

    const supabase = getSupabase();

    // ========== VERIFICAR EMAIL EXISTENTE ==========
    const { data: existingUser } = await supabase
      .from('users')
      .select('id')
      .eq('email', emailNormalized)
      .maybeSingle();

    if (existingUser) {
      return NextResponse.json(
        { error: 'Este email já está cadastrado. Faça login.' },
        { status: 409 }
      );
    }

    // ========== BUSCAR PLANO FREE ==========
    const { data: freePlan } = await supabase
      .from('developer_plans')
      .select('id')
      .eq('name', 'Free')
      .eq('is_active', true)
      .single();

    if (!freePlan) {
      console.error('Plano Free não encontrado na tabela developer_plans!');
      return NextResponse.json(
        { error: 'Erro de configuração. Contate o suporte.' },
        { status: 500 }
      );
    }

    // ========== GERAR SLUG ÚNICO ==========
    const baseSlug = company_name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');

    let finalSlug = baseSlug;
    let slugSuffix = 0;
    while (true) {
      const { data: existingSlug } = await supabase
        .from('developers')
        .select('id')
        .eq('slug', finalSlug)
        .maybeSingle();
      if (!existingSlug) break;
      slugSuffix++;
      finalSlug = `${baseSlug}-${slugSuffix}`;
    }

    // ========== CRIAR TUDO EM SEQUÊNCIA ==========
    const passwordHash = await bcrypt.hash(password, 10);

    // 1. Criar o Developer (empresa/conta)
    const { data: newDeveloper, error: devError } = await supabase
      .from('developers')
      .insert({
        name: company_name.trim(),
        slug: finalSlug,
        email: emailNormalized,
        plan_id: freePlan.id,
        status: 'active',
        self_registered: true,
        registered_at: new Date().toISOString(),
        primary_color: '#3B82F6',
        secondary_color: '#1E40AF',
      })
      .select('id, name, slug')
      .single();

    if (devError) {
      console.error('Erro ao criar developer:', devError);
      return NextResponse.json(
        { error: 'Erro ao criar conta. Tente novamente.' },
        { status: 500 }
      );
    }

    // 2. Criar o Usuário (owner do developer)
    const { data: newUser, error: userError } = await supabase
      .from('users')
      .insert({
        email: emailNormalized,
        full_name: full_name.trim(),
        password_hash: passwordHash,
        is_master: false,
        is_developer_user: true,
        developer_id: newDeveloper.id,
        status: 'active',
        self_registered: true,
        onboarding_completed: false,
      })
      .select('id, email, full_name')
      .single();

    if (userError) {
      console.error('Erro ao criar usuário:', userError);
      await supabase.from('developers').delete().eq('id', newDeveloper.id);
      return NextResponse.json(
        { error: 'Erro ao criar usuário. Tente novamente.' },
        { status: 500 }
      );
    }

    // 3. Criar developer_users (relação owner)
    const { error: devUserError } = await supabase
      .from('developer_users')
      .insert({
        developer_id: newDeveloper.id,
        user_id: newUser.id,
        role: 'owner',
        is_active: true,
      });

    if (devUserError) {
      console.error('Erro ao criar developer_users:', devUserError);
      await supabase.from('users').delete().eq('id', newUser.id);
      await supabase.from('developers').delete().eq('id', newDeveloper.id);
      return NextResponse.json(
        { error: 'Erro ao configurar conta. Tente novamente.' },
        { status: 500 }
      );
    }

    // ========== AUTO-LOGIN (JWT) ==========
    const tokenData = {
      id: newUser.id,
      email: newUser.email,
      name: newUser.full_name,
      role: 'developer',
      groupId: null,
      developerId: newDeveloper.id,
      isDeveloperUser: true,
      groupIds: [],
    };

    const token = jwt.sign(tokenData, jwtSecret, { expiresIn: '7d' });

    const response = NextResponse.json({
      success: true,
      user: {
        id: newUser.id,
        email: newUser.email,
        name: newUser.full_name,
        role: 'developer',
        developerId: newDeveloper.id,
        isDeveloperUser: true,
        groupIds: [],
      },
      developer: {
        id: newDeveloper.id,
        name: newDeveloper.name,
      },
      isNewUser: true,
    });

    response.cookies.set('auth-token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7 dias
      path: '/',
    });

    return response;
  } catch (error: any) {
    console.error('Erro no registro:', error);
    return NextResponse.json(
      { error: 'Erro interno. Tente novamente.' },
      { status: 500 }
    );
  }
}
