import { redirect } from 'next/navigation';

export default function WhatsAppPage() {
  redirect('/whatsapp/mensagens');
}
