'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import MainLayout from '@/components/layout/MainLayout';
import FeatureGate from '@/components/ui/FeatureGate';
import Button from '@/components/ui/Button';
import DatasetSelector from '@/components/whatsapp/DatasetSelector';
import { useMenu } from '@/contexts/MenuContext';
import { showToast } from '@/lib/toast';
import {
  Users,
  Plus,
  Edit,
  Trash2,
  Loader2,
  X,
  Search,
  Phone,
  MessageSquare,
  Bell,
  CheckCircle,
  XCircle
} from 'lucide-react';
import Pagination, { PAGE_SIZE } from '@/components/ui/Pagination';

interface AuthorizedNumber {
  id: string;
  phone_number: string;
  name: string;
  can_receive_alerts: boolean;
  can_use_chat: boolean;
  is_active: boolean;
  created_at: string;
  instance: { id: string; name: string } | null;
  datasets?: Array<{
    id: string;
    connection_id: string;
    dataset_id: string;
    dataset_name: string;
  }>;
}

interface Instance {
  id: string;
  name: string;
}

function NumerosContent() {
  const router = useRouter();
  const { activeGroup } = useMenu();
  const [user, setUser] = useState<any>(null);
  const [userRole, setUserRole] = useState<string>('loading');
  const [userGroupIds, setUserGroupIds] = useState<string[]>([]);
  
  const [numbers, setNumbers] = useState<AuthorizedNumber[]>([]);
  const [instances, setInstances] = useState<Instance[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterInstance, setFilterInstance] = useState('');
  const [page, setPage] = useState(1);

  const [showModal, setShowModal] = useState(false);
  const [editingNumber, setEditingNumber] = useState<AuthorizedNumber | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [numberToDelete, setNumberToDelete] = useState<AuthorizedNumber | null>(null);

  const [formData, setFormData] = useState({
    phone_number: '',
    name: '',
    instance_id: '',
    can_receive_alerts: true,
    can_use_chat: true,
    datasets: [] as Array<{connection_id: string, dataset_id: string, dataset_name: string}>
  });

  useEffect(() => {
    checkAccessAndLoad();
  }, []);

  useEffect(() => {
    if (userRole !== 'user') {
      loadNumbers(activeGroup);
    }
  }, [activeGroup, userRole]);

  async function checkAccessAndLoad() {
    try {
      const res = await fetch('/api/auth/me');
      const data = await res.json();
      
      if (!data.user) {
        router.push('/login');
        return;
      }
      
      setUser(data.user);
      
      if (data.user.is_master) {
        setUserRole('master');
      } else if (data.user.is_developer) {
        setUserRole('developer');
      } else if (data.role === 'admin') {
        setUserRole('admin');
        // IMPORTANTE: Garantir que groupIds está sendo setado
        setUserGroupIds(data.groupIds || []);
        console.log('Admin groupIds:', data.groupIds); // Debug
      } else {
        setUserRole('user');
      }
      
      loadData(activeGroup);
    } catch (error) {
      console.error('Erro ao verificar acesso:', error);
      router.push('/login');
    }
  }

  async function loadData(currentGroup?: { id: string; name: string } | null) {
    setLoading(true);
    await Promise.all([loadNumbers(currentGroup), loadInstances()]);
    setLoading(false);
  }

  async function loadNumbers(currentGroup?: { id: string; name: string } | null) {
    try {
      const url = currentGroup
        ? `/api/whatsapp/authorized-numbers?group_id=${currentGroup.id}`
        : '/api/whatsapp/authorized-numbers';
      
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setNumbers(data.numbers || []);
      }
    } catch (err) {
      console.error('Erro ao carregar números:', err);
    }
  }

  async function loadInstances() {
    try {
      const res = await fetch('/api/whatsapp/instances');
      if (res.ok) {
        const data = await res.json();
        setInstances(data.instances || []);
      }
    } catch (err) {
      console.error('Erro ao carregar instâncias:', err);
    }
  }

  function resetForm() {
    setFormData({
      phone_number: '',
      name: '',
      instance_id: '',
      can_receive_alerts: true,
      can_use_chat: true,
      datasets: []
    });
    setEditingNumber(null);
  }

  function openNew() {
    resetForm();
    setShowModal(true);
  }

  function openEdit(number: AuthorizedNumber) {
    setEditingNumber(number);
    // Converter datasets do formato da API para o formato do formData
    const datasets = (number.datasets || []).map((d: any) => ({
      connection_id: d.connection_id,
      dataset_id: d.dataset_id,
      dataset_name: d.dataset_name || d.dataset_id
    }));
    
    console.log('[DEBUG] Editando número:', {
      numberId: number.id,
      datasetsFromAPI: number.datasets,
      datasetsMapped: datasets
    });
    
    setFormData({
      phone_number: number.phone_number,
      name: number.name,
      instance_id: number.instance?.id || '',
      can_receive_alerts: number.can_receive_alerts,
      can_use_chat: number.can_use_chat,
      datasets: datasets
    });
    setShowModal(true);
  }

  async function handleSave() {
    if (!formData.phone_number || !formData.name) {
      showToast('Telefone e nome são obrigatórios', 'error');
      return;
    }

    setSaving(true);
    try {
      console.log('[DEBUG] Salvando número:', {
        editing: !!editingNumber,
        datasets: formData.datasets,
        activeGroup: activeGroup?.id
      });
      
      const payload: any = {
        phone_number: formData.phone_number,
        name: formData.name,
        instance_id: formData.instance_id || null,
        can_receive_alerts: formData.can_receive_alerts,
        can_use_chat: formData.can_use_chat,
        datasets: formData.datasets || [] // Garantir que sempre seja um array
      };

      // Se admin ou developer, adicionar company_group_id
      if ((userRole === 'admin' || userRole === 'developer') && activeGroup) {
        payload.company_group_id = activeGroup.id;
      } else if (userGroupIds.length > 0) {
        payload.company_group_id = userGroupIds[0];
      }

      if (editingNumber) {
        payload.id = editingNumber.id;
        payload.is_active = editingNumber.is_active;
      }

      const res = await fetch('/api/whatsapp/authorized-numbers', {
        method: editingNumber ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        showToast(editingNumber ? 'Número atualizado!' : 'Número autorizado!', 'success');
        setShowModal(false);
        resetForm();
        loadNumbers(activeGroup);
      } else {
        const data = await res.json();
        showToast(data.error || 'Erro ao salvar', 'error');
      }
    } catch (err) {
      showToast('Erro ao salvar número', 'error');
    } finally {
      setSaving(false);
    }
  }

  function openDeleteModal(number: AuthorizedNumber) {
    setNumberToDelete(number);
    setShowDeleteModal(true);
  }

  function closeDeleteModal() {
    setShowDeleteModal(false);
    setNumberToDelete(null);
  }

  async function handleDelete() {
    if (!numberToDelete) return;

    try {
      const res = await fetch(`/api/whatsapp/authorized-numbers?id=${numberToDelete.id}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Número removido!', 'success');
        closeDeleteModal();
        loadNumbers(activeGroup);
      } else {
        const data = await res.json();
        showToast(data.error || 'Erro ao remover', 'error');
      }
    } catch (err) {
      showToast('Erro ao remover número', 'error');
    }
  }

  async function toggleActive(number: AuthorizedNumber) {
    try {
      const res = await fetch('/api/whatsapp/authorized-numbers', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: number.id,
          phone_number: number.phone_number,
          name: number.name,
          is_active: !number.is_active
        })
      });

      if (res.ok) {
        loadNumbers(activeGroup);
      }
    } catch (err) {
      console.error('Erro ao atualizar:', err);
    }
  }

  function formatPhone(phone: string) {
    if (!phone) return '-';
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 13) {
      return `+${cleaned.slice(0, 2)} (${cleaned.slice(2, 4)}) ${cleaned.slice(4, 9)}-${cleaned.slice(9)}`;
    }
    if (cleaned.length === 12) {
      return `+${cleaned.slice(0, 2)} (${cleaned.slice(2, 4)}) ${cleaned.slice(4, 8)}-${cleaned.slice(8)}`;
    }
    return phone;
  }

  const filteredNumbers = numbers.filter(num => {
    // Filtro de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const matchesSearch = num.name.toLowerCase().includes(term) || num.phone_number.includes(term);
      if (!matchesSearch) return false;
    }
    
    // Filtro de instância
    if (filterInstance) {
      if (filterInstance === 'sem-instancia') {
        return !num.instance;
      }
      return num.instance?.id === filterInstance;
    }
    
    return true;
  });
  useEffect(() => {
    setPage(1);
  }, [searchTerm, filterInstance]);
  const paginatedNumbers = filteredNumbers.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  // Loading state
  if (userRole === 'loading') {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Módulos removidos - sempre disponível
  // Verificação de módulo removida

  return (
    <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Números Autorizados</h1>
            <p className="text-gray-500 text-sm mt-1">Gerencie os números que podem interagir com o sistema</p>
          </div>
          <Button onClick={openNew} icon={<Plus size={20} />}>
            Novo Número
          </Button>
        </div>

        {/* Busca e Filtros */}
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Buscar por nome ou telefone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-lg focus:outline-none focus:border-blue-500"
            />
          </div>
          <select
            value={filterInstance}
            onChange={(e) => setFilterInstance(e.target.value)}
            className="px-4 py-2 bg-white border border-gray-200 rounded-lg focus:outline-none focus:border-blue-500 min-w-[200px]"
          >
            <option value="">Todas as instâncias</option>
            <option value="sem-instancia">Sem instância</option>
            {instances.map(inst => (
              <option key={inst.id} value={inst.id}>{inst.name}</option>
            ))}
          </select>
        </div>

        {/* Lista */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : (
          <div className="overflow-hidden">
            <table className="w-full table-modern">
              <thead>
                <tr>
                  <th>Contato</th>
                  <th>Instância</th>
                  <th>Datasets</th>
                  <th className="text-center">Alertas</th>
                  <th className="text-center">Chat IA</th>
                  <th className="text-center">Status</th>
                  <th className="text-right">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredNumbers.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-4 py-8 text-center text-gray-500">
                      <Phone className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                      Nenhum número autorizado
                    </td>
                  </tr>
                ) : (
                  paginatedNumbers.map((num) => (
                    <tr key={num.id}>
                      <td>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                            <Phone className="text-blue-600" size={18} />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{num.name}</p>
                            <p className="text-sm text-gray-500">{formatPhone(num.phone_number)}</p>
                          </div>
                        </div>
                      </td>
                      <td className="text-sm text-gray-600">
                        {num.instance?.name || '-'}
                      </td>
                      <td>
                        <div className="flex flex-wrap gap-1">
                          {num.datasets && num.datasets.length > 0 ? (
                            num.datasets.map((d: any) => (
                              <span 
                                key={`${d.connection_id}-${d.dataset_id}`}
                                className="px-2 py-0.5 text-xs bg-green-100 text-green-800 rounded-full"
                              >
                                {d.dataset_name || d.dataset_id}
                              </span>
                            ))
                          ) : (
                            <span className="text-gray-400 text-sm">Nenhum</span>
                          )}
                        </div>
                      </td>
                      <td className="text-center">
                        {num.can_receive_alerts ? (
                          <Bell className="w-5 h-5 text-green-600 mx-auto" />
                        ) : (
                          <Bell className="w-5 h-5 text-gray-300 mx-auto" />
                        )}
                      </td>
                      <td className="text-center">
                        {num.can_use_chat ? (
                          <MessageSquare className="w-5 h-5 text-green-600 mx-auto" />
                        ) : (
                          <MessageSquare className="w-5 h-5 text-gray-300 mx-auto" />
                        )}
                      </td>
                      <td className="text-center">
                        <button
                          onClick={() => toggleActive(num)}
                          className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                            num.is_active
                              ? 'bg-green-100 text-green-700'
                              : 'bg-gray-100 text-gray-600'
                          }`}
                        >
                          {num.is_active ? <CheckCircle size={12} /> : <XCircle size={12} />}
                          {num.is_active ? 'Ativo' : 'Inativo'}
                        </button>
                      </td>
                      <td>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => openEdit(num)}
                            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Editar"
                          >
                            <Edit size={16} />
                          </button>
                          <button
                            onClick={() => openDeleteModal(num)}
                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Excluir"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="mt-4">
            <Pagination totalItems={filteredNumbers.length} currentPage={page} onPageChange={setPage} pageSize={PAGE_SIZE} />
          </div>
        )}

        {/* Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between p-4 border-b border-gray-200 sticky top-0 bg-white">
                <h2 className="text-lg font-bold text-gray-900">
                  {editingNumber ? 'Editar Número' : 'Novo Número Autorizado'}
                </h2>
                <button
                  onClick={() => { setShowModal(false); resetForm(); }}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-4 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nome *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ex: João Silva"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Telefone *</label>
                  <input
                    type="tel"
                    value={formData.phone_number}
                    onChange={(e) => setFormData({ ...formData, phone_number: e.target.value })}
                    placeholder="5511999999999"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                  <p className="text-xs text-gray-500 mt-1">Formato: código do país + DDD + número (ex: 5511999999999)</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Instância</label>
                  <select
                    value={formData.instance_id}
                    onChange={(e) => setFormData({ ...formData, instance_id: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:border-blue-500"
                  >
                    <option value="">Todas as instâncias</option>
                    {instances.map(inst => (
                      <option key={inst.id} value={inst.id}>{inst.name}</option>
                    ))}
                  </select>
                </div>

                {/* DatasetSelector */}
                <DatasetSelector
                  companyGroupId={activeGroup?.id || (userRole === 'admin' ? userGroupIds[0] : undefined)}
                  selectedDatasets={formData.datasets}
                  onChange={(datasets) => setFormData({...formData, datasets})}
                />

                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="can_receive_alerts"
                      checked={formData.can_receive_alerts}
                      onChange={(e) => setFormData({ ...formData, can_receive_alerts: e.target.checked })}
                      className="w-4 h-4 rounded border-gray-300"
                    />
                    <label htmlFor="can_receive_alerts" className="text-sm text-gray-700 flex items-center gap-2">
                      <Bell size={16} className="text-gray-400" />
                      Pode receber alertas
                    </label>
                  </div>

                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="can_use_chat"
                      checked={formData.can_use_chat}
                      onChange={(e) => setFormData({ ...formData, can_use_chat: e.target.checked })}
                      className="w-4 h-4 rounded border-gray-300"
                    />
                    <label htmlFor="can_use_chat" className="text-sm text-gray-700 flex items-center gap-2">
                      <MessageSquare size={16} className="text-gray-400" />
                      Pode usar Chat IA
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 p-4 border-t border-gray-200 bg-gray-50 rounded-b-xl sticky bottom-0">
                <button
                  onClick={() => { setShowModal(false); resetForm(); }}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <Button
                  onClick={handleSave}
                  loading={saving}
                >
                  {editingNumber ? 'Salvar' : 'Autorizar'}
                </Button>
              </div>
            </div>
          </div>
        )}

      {/* Modal de Confirmação de Exclusão */}
      {showDeleteModal && numberToDelete && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl w-full max-w-md shadow-xl">
            <div className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                  <Trash2 className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Excluir Número</h3>
                  <p className="text-sm text-gray-500">Esta ação não pode ser desfeita</p>
                </div>
              </div>
              
              <p className="text-gray-700 mb-6">
                Tem certeza que deseja remover o número autorizado <span className="font-semibold">"{numberToDelete.name}"</span>?
              </p>

              <div className="flex items-center justify-end gap-3">
                <button
                  onClick={closeDeleteModal}
                  className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleDelete}
                  className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white transition-colors"
                >
                  Excluir
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      </div>
  );
}

export default function NumerosPage() {
  return (
    <MainLayout>
      <FeatureGate feature="whatsapp">
        <NumerosContent />
      </FeatureGate>
    </MainLayout>
  );
}
