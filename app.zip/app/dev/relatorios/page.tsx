'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import MainLayout from '@/components/layout/MainLayout';
import {
  BarChart3,
  Calendar,
  Download,
  Filter,
  Loader2,
  MessageSquare,
  Sparkles,
  Bell,
  TrendingUp,
  TrendingDown,
  Building2,
  Users
} from 'lucide-react';

interface DailyUsage {
  usage_date: string;
  whatsapp_messages_sent: number;
  ai_credits_used: number;
  alert_executions: number;
  company_group_id: string;
  group_name?: string;
}

interface GroupOption {
  id: string;
  name: string;
}

type PeriodType = 'today' | '7days' | '30days' | 'custom';

export default function DevRelatoriosPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [usageData, setUsageData] = useState<DailyUsage[]>([]);
  const [groups, setGroups] = useState<GroupOption[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<string>('all');
  const [period, setPeriod] = useState<PeriodType>('30days');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [totals, setTotals] = useState({
    whatsapp: 0,
    ai: 0,
    alerts: 0
  });
  const [accessData, setAccessData] = useState<{
    accessByDay: { date: string; count: number }[];
    accessByUser: { userId: string; userName: string; count: number }[];
    accessByGroup: { groupId: string; groupName: string; count: number }[];
    totalAccess: number;
  }>({
    accessByDay: [],
    accessByUser: [],
    accessByGroup: [],
    totalAccess: 0
  });

  useEffect(() => {
    loadGroups();
  }, []);

  useEffect(() => {
    loadUsageData();
    loadAccessData();
  }, [selectedGroup, period, customStartDate, customEndDate]);

  async function loadGroups() {
    try {
      const res = await fetch('/api/dev/groups');
      if (res.ok) {
        const data = await res.json();
        setGroups(data.groups || []);
      }
    } catch (error) {
      console.error('Erro ao carregar grupos:', error);
    }
  }

  async function loadUsageData() {
    try {
      setLoading(true);
      
      // Calcular datas baseado no periodo
      const endDate = new Date();
      let startDate = new Date();
      
      switch (period) {
        case 'today':
          startDate = new Date();
          break;
        case '7days':
          startDate.setDate(startDate.getDate() - 7);
          break;
        case '30days':
          startDate.setDate(startDate.getDate() - 30);
          break;
        case 'custom':
          if (customStartDate && customEndDate) {
            startDate = new Date(customStartDate);
            endDate.setTime(new Date(customEndDate).getTime());
          }
          break;
      }

      const params = new URLSearchParams({
        start_date: startDate.toISOString().split('T')[0],
        end_date: endDate.toISOString().split('T')[0],
      });

      if (selectedGroup !== 'all') {
        params.append('group_id', selectedGroup);
      }

      const res = await fetch(`/api/dev/usage?${params}`);
      if (res.status === 403) {
        router.push('/dashboard');
        return;
      }

      if (res.ok) {
        const data = await res.json();
        setUsageData(data.usage || []);
        
        // Calcular totais
        const totalWhatsapp = (data.usage || []).reduce((sum: number, d: DailyUsage) => sum + d.whatsapp_messages_sent, 0);
        const totalAi = (data.usage || []).reduce((sum: number, d: DailyUsage) => sum + d.ai_credits_used, 0);
        const totalAlerts = (data.usage || []).reduce((sum: number, d: DailyUsage) => sum + d.alert_executions, 0);
        
        setTotals({
          whatsapp: totalWhatsapp,
          ai: totalAi,
          alerts: totalAlerts
        });
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  }

  async function loadAccessData() {
    try {
      // Calcular datas baseado no periodo
      const endDate = new Date();
      let startDate = new Date();

      switch (period) {
        case 'today':
          startDate = new Date();
          break;
        case '7days':
          startDate.setDate(startDate.getDate() - 7);
          break;
        case '30days':
          startDate.setDate(startDate.getDate() - 30);
          break;
        case 'custom':
          if (customStartDate && customEndDate) {
            startDate = new Date(customStartDate);
            endDate.setTime(new Date(customEndDate).getTime());
          }
          break;
      }

      const params = new URLSearchParams({
        start_date: startDate.toISOString().split('T')[0],
        end_date: endDate.toISOString().split('T')[0],
      });

      if (selectedGroup !== 'all') {
        params.append('group_id', selectedGroup);
      }

      const res = await fetch(`/api/dev/access-logs?${params}`);
      
      if (res.ok) {
        const data = await res.json();
        setAccessData({
          accessByDay: data.accessByDay || [],
          accessByUser: data.accessByUser || [],
          accessByGroup: data.accessByGroup || [],
          totalAccess: data.totalAccess || 0
        });
      }
    } catch (error) {
      console.error('Erro ao carregar dados de acesso:', error);
      // Em caso de erro, manter valores zerados
      setAccessData({
        accessByDay: [],
        accessByUser: [],
        accessByGroup: [],
        totalAccess: 0
      });
    }
  }

  function formatDate(dateStr: string) {
    const date = new Date(dateStr + 'T00:00:00');
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  }

  function getPeriodLabel() {
    switch (period) {
      case 'today': return 'Hoje';
      case '7days': return 'Ultimos 7 dias';
      case '30days': return 'Ultimos 30 dias';
      case 'custom': return 'Periodo personalizado';
    }
  }

  // Agrupar dados por data para o grafico
  const groupedByDate = usageData.reduce((acc, item) => {
    const date = item.usage_date;
    if (!acc[date]) {
      acc[date] = { whatsapp: 0, ai: 0, alerts: 0 };
    }
    acc[date].whatsapp += item.whatsapp_messages_sent;
    acc[date].ai += item.ai_credits_used;
    acc[date].alerts += item.alert_executions;
    return acc;
  }, {} as Record<string, { whatsapp: number; ai: number; alerts: number }>);

  const chartData = Object.entries(groupedByDate)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, values]) => ({ date, ...values }));

  // Calcular valor maximo para escala do grafico
  const maxValue = Math.max(
    ...chartData.map(d => Math.max(d.whatsapp, d.ai, d.alerts)),
    1
  );

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Relatorios de Consumo</h1>
            <p className="text-gray-500 mt-1">Analise detalhada do uso dos recursos</p>
          </div>
          <button
            onClick={() => {/* TODO: exportar */}}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <Download className="w-5 h-5" />
            Exportar Excel
          </button>
        </div>

        {/* Filtros */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Filtro de Periodo */}
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">Periodo</label>
              <div className="flex flex-wrap gap-2">
                {[
                  { value: 'today', label: 'Hoje' },
                  { value: '7days', label: '7 dias' },
                  { value: '30days', label: '30 dias' },
                  { value: 'custom', label: 'Personalizado' },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => setPeriod(opt.value as PeriodType)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                      period === opt.value
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Filtro de Grupo */}
            <div className="w-full sm:w-64">
              <label className="block text-sm font-medium text-gray-700 mb-1">Grupo</label>
              <select
                value={selectedGroup}
                onChange={(e) => setSelectedGroup(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Todos os grupos</option>
                {groups.map((group) => (
                  <option key={group.id} value={group.id}>{group.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Datas personalizadas */}
          {period === 'custom' && (
            <div className="flex flex-col sm:flex-row gap-4 mt-4 pt-4 border-t border-gray-100">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Data Inicio</label>
                <input
                  type="date"
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  className="px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Data Fim</label>
                <input
                  type="date"
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  className="px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          )}
        </div>

        {/* Cards de Totais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">WhatsApp</p>
                <p className="text-2xl font-bold text-gray-900">{totals.whatsapp.toLocaleString()}</p>
              </div>
            </div>
            <p className="text-xs text-gray-500">{getPeriodLabel()}</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Creditos IA</p>
                <p className="text-2xl font-bold text-gray-900">{totals.ai.toLocaleString()}</p>
              </div>
            </div>
            <p className="text-xs text-gray-500">{getPeriodLabel()}</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Bell className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Execucoes de Alerta</p>
                <p className="text-2xl font-bold text-gray-900">{totals.alerts.toLocaleString()}</p>
              </div>
            </div>
            <p className="text-xs text-gray-500">{getPeriodLabel()}</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Acessos</p>
                <p className="text-2xl font-bold text-gray-900">{accessData.totalAccess.toLocaleString()}</p>
              </div>
            </div>
            <p className="text-xs text-gray-500">{getPeriodLabel()}</p>
          </div>
        </div>

        {/* Grafico de Barras Simples */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Evolucao do Consumo</h3>
          
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            </div>
          ) : chartData.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-gray-500">
              <BarChart3 className="w-12 h-12 mb-2 text-gray-300" />
              <p>Nenhum dado para o periodo selecionado</p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Legenda */}
              <div className="flex flex-wrap gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded"></div>
                  <span>WhatsApp</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-purple-500 rounded"></div>
                  <span>Creditos IA</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded"></div>
                  <span>Alertas</span>
                </div>
              </div>

              {/* Grafico */}
              <div className="overflow-x-auto">
                <div className="flex items-end gap-1 h-48 min-w-fit">
                  {chartData.map((item, idx) => (
                    <div key={idx} className="flex flex-col items-center gap-1" style={{ minWidth: '40px' }}>
                      <div className="flex items-end gap-0.5 h-40">
                        <div
                          className="w-2.5 bg-green-500 rounded-t transition-all"
                          style={{ height: `${(item.whatsapp / maxValue) * 100}%`, minHeight: item.whatsapp > 0 ? '4px' : '0' }}
                          title={`WhatsApp: ${item.whatsapp}`}
                        ></div>
                        <div
                          className="w-2.5 bg-purple-500 rounded-t transition-all"
                          style={{ height: `${(item.ai / maxValue) * 100}%`, minHeight: item.ai > 0 ? '4px' : '0' }}
                          title={`IA: ${item.ai}`}
                        ></div>
                        <div
                          className="w-2.5 bg-yellow-500 rounded-t transition-all"
                          style={{ height: `${(item.alerts / maxValue) * 100}%`, minHeight: item.alerts > 0 ? '4px' : '0' }}
                          title={`Alertas: ${item.alerts}`}
                        ></div>
                      </div>
                      <span className="text-xs text-gray-500 -rotate-45 origin-top-left whitespace-nowrap">
                        {formatDate(item.date)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Graficos de Acesso */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Grafico: Acessos por Dia */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Acessos por Dia</h3>
            
            {loading ? (
              <div className="flex items-center justify-center h-48">
                <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
              </div>
            ) : accessData.accessByDay.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-gray-500">
                <Users className="w-10 h-10 mb-2 text-gray-300" />
                <p className="text-sm">Nenhum acesso no periodo</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <div className="flex items-end gap-1 h-40 min-w-fit">
                  {accessData.accessByDay.map((item, idx) => {
                    const maxAccess = Math.max(...accessData.accessByDay.map(d => d.count), 1);
                    return (
                      <div key={idx} className="flex flex-col items-center gap-1" style={{ minWidth: '30px' }}>
                        <div
                          className="w-6 bg-blue-500 rounded-t transition-all hover:bg-blue-600"
                          style={{ 
                            height: `${(item.count / maxAccess) * 100}%`, 
                            minHeight: item.count > 0 ? '4px' : '0' 
                          }}
                          title={`${item.count} acessos`}
                        ></div>
                        <span className="text-xs text-gray-500 -rotate-45 origin-top-left whitespace-nowrap">
                          {formatDate(item.date)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Grafico: Top Usuarios */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Top 10 Usuarios</h3>
            
            {loading ? (
              <div className="flex items-center justify-center h-48">
                <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
              </div>
            ) : accessData.accessByUser.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-gray-500">
                <Users className="w-10 h-10 mb-2 text-gray-300" />
                <p className="text-sm">Nenhum acesso no periodo</p>
              </div>
            ) : (
              <div className="space-y-2">
                {accessData.accessByUser.map((item, idx) => {
                  const maxCount = accessData.accessByUser[0]?.count || 1;
                  return (
                    <div key={idx} className="flex items-center gap-3">
                      <span className="text-xs text-gray-500 w-4">{idx + 1}</span>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm text-gray-700 truncate max-w-[150px]">{item.userName}</span>
                          <span className="text-sm font-medium text-gray-900">{item.count}</span>
                        </div>
                        <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-blue-500 rounded-full transition-all"
                            style={{ width: `${(item.count / maxCount) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Grafico: Acessos por Grupo */}
        {selectedGroup === 'all' && accessData.accessByGroup.length > 0 && (
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Acessos por Grupo</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {accessData.accessByGroup.map((item, idx) => {
                const maxCount = accessData.accessByGroup[0]?.count || 1;
                const percentage = Math.round((item.count / accessData.totalAccess) * 100);
                return (
                  <div key={idx} className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-900 truncate">{item.groupName}</span>
                      <span className="text-lg font-bold text-blue-600">{item.count}</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden mb-1">
                      <div 
                        className="h-full bg-blue-500 rounded-full transition-all"
                        style={{ width: `${(item.count / maxCount) * 100}%` }}
                      ></div>
                    </div>
                    <span className="text-xs text-gray-500">{percentage}% do total</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tabela Detalhada */}
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="p-5 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Detalhamento por Dia</h3>
          </div>
          
          {loading ? (
            <div className="flex items-center justify-center h-32">
              <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
            </div>
          ) : chartData.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              Nenhum dado para o periodo selecionado
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Data</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">WhatsApp</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">Creditos IA</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">Alertas</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {chartData.map((item, idx) => (
                    <tr key={idx} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm text-gray-900">
                        {new Date(item.date + 'T00:00:00').toLocaleDateString('pt-BR')}
                      </td>
                      <td className="px-4 py-3 text-sm text-right text-gray-900">{item.whatsapp.toLocaleString()}</td>
                      <td className="px-4 py-3 text-sm text-right text-gray-900">{item.ai.toLocaleString()}</td>
                      <td className="px-4 py-3 text-sm text-right text-gray-900">{item.alerts.toLocaleString()}</td>
                      <td className="px-4 py-3 text-sm text-right font-medium text-gray-900">
                        {(item.whatsapp + item.ai + item.alerts).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-gray-50 font-medium">
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-900">Total</td>
                    <td className="px-4 py-3 text-sm text-right text-gray-900">{totals.whatsapp.toLocaleString()}</td>
                    <td className="px-4 py-3 text-sm text-right text-gray-900">{totals.ai.toLocaleString()}</td>
                    <td className="px-4 py-3 text-sm text-right text-gray-900">{totals.alerts.toLocaleString()}</td>
                    <td className="px-4 py-3 text-sm text-right text-gray-900">
                      {(totals.whatsapp + totals.ai + totals.alerts).toLocaleString()}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
